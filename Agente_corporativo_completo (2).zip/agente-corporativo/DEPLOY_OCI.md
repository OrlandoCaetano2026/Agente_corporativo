# ☁️ Guia de Deploy no OCI (Oracle Cloud) — sem Docker

Publica o **Agente de Suporte SAP da Orla_Tech** na nuvem Oracle (OCI) usando
**apenas Python** — sem Docker, ideal para quem não pode instalar Docker no PC.

> ✅ Atende o requisito do desafio (usar **pelo menos um serviço OCI**) com uma
> **VM Compute (Always Free)**. Opcional: **Object Storage** para os documentos.

---

## Passo 1 — Criar a VM no OCI
1. Conta em **oracle.com/cloud/free** (Always Free).
2. **Compute → Instances → Create Instance**.
3. **Image:** Ubuntu 22.04 · **Shape:** `VM.Standard.E2.1.Micro` (Always Free).
4. Gere/baixe a **chave SSH** e anote o **IP público**.

## Passo 2 — Liberar a porta 8501
Subnet → **Security List → Add Ingress Rules**:
- Source CIDR `0.0.0.0/0` · TCP · Destination Port `8501`.

## Passo 3 — Conectar via SSH
```bash
ssh -i sua-chave.key ubuntu@SEU_IP_PUBLICO
```

## Passo 4 — Instalar e clonar
```bash
sudo apt update && sudo apt install -y python3-pip python3-venv git
git clone https://github.com/OrlandoCaetano2026/Agente_corporativo.git
cd Agente_corporativo
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
```

## Passo 5 — Configurar a chave da LLM (Groq)
```bash
export GROQ_API_KEY="sua-chave-aqui"
# opcional: torne permanente adicionando a linha ao ~/.bashrc
```

## Passo 6 — Abrir a porta no firewall do Ubuntu
```bash
sudo iptables -I INPUT -p tcp --dport 8501 -j ACCEPT
```

## Passo 7 — Rodar o agente (fica ativo após fechar o SSH)
```bash
nohup streamlit run app/main.py \
    --server.port=8501 --server.address=0.0.0.0 --server.headless=true &
```

## Passo 8 — Acessar
```
http://SEU_IP_PUBLICO:8501
```
🎉 O agente estará rodando na nuvem Oracle!

---

## 📸 Registrar a execução (Passo 9 do desafio)
1. Acesse o agente pelo IP público e faça uma pergunta.
2. Tire um **print** (com o IP na barra de endereço) ou grave um **vídeo**.
3. Salve em `assets/` (ex.: `assets/demo_oci.png`).
4. O README já referencia essa imagem na seção de deploy.

## 🗄️ (Opcional) OCI Object Storage
1. **Storage → Buckets → Create Bucket** (ex.: `orla-tech-docs`).
2. Upload dos arquivos de `data/documentos/`.
3. Em cada objeto → **Pre-Authenticated Request** → gera URL HTTP pública
   (útil como a "imagem via HTTP" exigida no desafio).

## 🔧 Manutenção
- Logs: `cat nohup.out` · Parar: `pkill -f streamlit`
- Atualizar: `git pull` e reinicie o Streamlit
- Rodar a API: `uvicorn src.api:app --host 0.0.0.0 --port 8000`
