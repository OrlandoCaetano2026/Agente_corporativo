# -*- coding: utf-8 -*-
"""
document_loader.py  — PASSO 3: Processamento e extração de conteúdo
-------------------------------------------------------------------
Lê os documentos da base de conhecimento em múltiplos formatos e devolve
uma lista de "chunks" (trechos de texto) prontos para indexação vetorial.

Formatos suportados (Orla_Tech):
  - PDF   (.pdf)   -> base de conhecimento / FAQ
  - DOCX  (.docx)  -> manual de procedimentos
  - XLSX  (.xlsx)  -> planilha de chamados/incidentes
  - Imagem(.png)   -> registrada como referência textual (legenda)

Extensível a CSV, JSON, HTML, PPT etc.
"""
from __future__ import annotations
import os
from dataclasses import dataclass
from typing import List

import pandas as pd
from pypdf import PdfReader
import docx  # python-docx


@dataclass
class Chunk:
    texto: str
    fonte: str
    tipo: str
    meta: dict


def _ler_pdf(path: str) -> List[Chunk]:
    chunks = []
    reader = PdfReader(path)
    nome = os.path.basename(path)
    for i, page in enumerate(reader.pages, start=1):
        texto = (page.extract_text() or "").strip()
        if texto:
            chunks.append(Chunk(texto=texto, fonte=nome, tipo="pdf", meta={"pagina": i}))
    return chunks


def _ler_docx(path: str) -> List[Chunk]:
    nome = os.path.basename(path)
    d = docx.Document(path)
    partes = []
    for p in d.paragraphs:
        if p.text.strip():
            partes.append(p.text.strip())
    for tbl in d.tables:
        for row in tbl.rows:
            linha = " | ".join(cel.text.strip() for cel in row.cells if cel.text.strip())
            if linha:
                partes.append(linha)
    return _dividir("\n".join(partes), nome, "docx")


def _ler_xlsx(path: str) -> List[Chunk]:
    nome = os.path.basename(path)
    chunks = []
    sheets = pd.read_excel(path, sheet_name=None, dtype=str)
    for aba, df in sheets.items():
        df = df.fillna("")
        for _, row in df.iterrows():
            pares = [f"{col}: {val}" for col, val in row.items() if str(val).strip()]
            if pares:
                chunks.append(Chunk(texto="; ".join(pares), fonte=nome,
                                    tipo="xlsx", meta={"aba": aba}))
    return chunks


def _ler_imagem(path: str) -> List[Chunk]:
    nome = os.path.basename(path)
    legenda = (
        "Imagem do fluxo de atendimento de suporte SAP da Orla_Tech. "
        "Mostra o processo: colaborador faz a pergunta; o agente de IA consulta "
        "a base de conhecimento; se a resposta existir, responde com a solução; "
        "caso contrário, orienta consultar o portal e oferece registrar um chamado "
        "no ServiceToday. Abrange os módulos SAP MM (foco), PP, QM, WM, os sistemas "
        "ECC e S/4HANA e os MES Opcenter e PAS-X."
    )
    return [Chunk(texto=legenda, fonte=nome, tipo="imagem", meta={})]


def _dividir(texto: str, fonte: str, tipo: str, tam: int = 800, overlap: int = 100) -> List[Chunk]:
    linhas = texto.split("\n")
    chunks, buffer = [], ""
    for ln in linhas:
        if len(buffer) + len(ln) + 1 > tam and buffer:
            chunks.append(Chunk(texto=buffer.strip(), fonte=fonte, tipo=tipo, meta={}))
            buffer = buffer[-overlap:] + "\n" + ln
        else:
            buffer += ("\n" if buffer else "") + ln
    if buffer.strip():
        chunks.append(Chunk(texto=buffer.strip(), fonte=fonte, tipo=tipo, meta={}))
    return chunks


EXTRATORES = {
    ".pdf": _ler_pdf, ".docx": _ler_docx, ".xlsx": _ler_xlsx,
    ".png": _ler_imagem, ".jpg": _ler_imagem, ".jpeg": _ler_imagem,
}


def carregar_documentos(pasta: str) -> List[Chunk]:
    todos: List[Chunk] = []
    for arq in sorted(os.listdir(pasta)):
        ext = os.path.splitext(arq)[1].lower()
        extrator = EXTRATORES.get(ext)
        if extrator:
            todos.extend(extrator(os.path.join(pasta, arq)))
    return todos


if __name__ == "__main__":
    base = os.path.join(os.path.dirname(__file__), "..", "data", "documentos")
    chunks = carregar_documentos(base)
    print(f"Total de chunks extraídos: {len(chunks)}")
    from collections import Counter
    print("Por tipo:", dict(Counter(c.tipo for c in chunks)))
