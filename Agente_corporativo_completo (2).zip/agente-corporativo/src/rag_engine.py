# -*- coding: utf-8 -*-
"""
rag_engine.py — PASSOS 4, 5 e 6: Indexação vetorial, recuperação (RAG) e geração
--------------------------------------------------------------------------------
Núcleo do agente:

  PASSO 4 - Indexação vetorial: embeddings (HuggingFace) + índice FAISS.
  PASSO 5 - Recuperação (Retriever): busca os trechos mais relevantes.
  PASSO 6 - Geração e validação: monta o contexto e chama a LLM (Groq).
            Se o contexto NÃO for suficiente (baixa similaridade), o agente NÃO
            inventa: contorna de forma cordial e oferece registrar um chamado.

Portabilidade:
  - Roda no Google Colab e no OCI.
  - LLM plugável (GROQ por padrão, ex.: Llama 3.3 70B). Sem GROQ_API_KEY, o motor
    funciona em "modo recuperação" (retorna os trechos) para testes locais.
"""
from __future__ import annotations
import os
from typing import List, Tuple, Optional

from document_loader import carregar_documentos, Chunk

# ============ REGRAS DO RAG (ajuste aqui) ============
# Limiar de similaridade: abaixo disso, considera-se que a base NÃO tem resposta.
LIMIAR_SIMILARIDADE = float(os.getenv("RAG_LIMIAR", "0.50"))
TOP_K = int(os.getenv("RAG_TOP_K", "4"))
# =====================================================

# Mensagem de contorno cordial (quando a base não tem a informação).
MSG_SEM_RESPOSTA = (
    "Não localizei essa informação específica na base de conhecimento atual. "
    "Recomendo consultar os documentos disponibilizados no portal da companhia. "
    "Caso não encontre o que precisa, posso registrar um chamado para que um "
    "especialista valide o caso — deseja que eu faça isso? "
    "Se sim, para qual ferramenta: SAP ou MES?"
)


class RAGEngine:
    def __init__(self, pasta_documentos: str,
                 modelo_embeddings: str = "sentence-transformers/all-MiniLM-L6-v2"):
        self.pasta = pasta_documentos
        self.modelo_embeddings = modelo_embeddings
        self.chunks: List[Chunk] = []
        self._vectorstore = None
        self._embeddings = None
        self._llm = None

    # ---------- PASSO 4: indexação ----------
    def indexar(self):
        self.chunks = carregar_documentos(self.pasta)
        if not self.chunks:
            raise RuntimeError("Nenhum documento encontrado para indexar.")

        from langchain_community.vectorstores import FAISS
        from langchain_community.embeddings import HuggingFaceEmbeddings

        self._embeddings = HuggingFaceEmbeddings(model_name=self.modelo_embeddings)
        textos = [c.texto for c in self.chunks]
        metadados = [{"fonte": c.fonte, "tipo": c.tipo, **c.meta} for c in self.chunks]
        self._vectorstore = FAISS.from_texts(textos, self._embeddings, metadatas=metadados)
        return len(self.chunks)

    # ---------- PASSO 5: recuperação ----------
    def recuperar(self, pergunta: str, k: int = TOP_K) -> List[Tuple[str, dict, float]]:
        if self._vectorstore is None:
            raise RuntimeError("Índice não construído. Chame indexar() primeiro.")
        docs = self._vectorstore.similarity_search_with_score(pergunta, k=k)
        resultados = []
        for doc, dist in docs:
            similaridade = 1.0 / (1.0 + float(dist))
            resultados.append((doc.page_content, doc.metadata, similaridade))
        return resultados

    # ---------- PASSO 6: geração ----------
    def _get_llm(self):
        if self._llm is not None:
            return self._llm
        api_key = os.getenv("GROQ_API_KEY")
        if not api_key:
            return None
        from langchain_groq import ChatGroq
        modelo = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
        self._llm = ChatGroq(model=modelo, temperature=0.1)
        return self._llm

    def _montar_prompt(self, contexto: str, pergunta: str) -> str:
        return f"""Você é um especialista SAP da Orla_Tech Consultoria, atuando como
assistente oficial de suporte. Seu tom deve ser SEMPRE profissional, formal e cordial.

INSTRUÇÕES DE RESPOSTA:
1. Responda APENAS com base no CONTEXTO fornecido abaixo. Nunca invente informações.
2. Estruture a resposta em TÓPICOS (passos numerados ou bullets), de forma clara e organizada.
3. Sempre que a informação envolver uma transação SAP, cite o TCODE correspondente
   (ex.: ME21N, ME29N, MIGO, MIRO, MRBR, CO11N, MD01N, QA32, LT01).
4. Ao final, cite a fonte consultada.
5. Se o CONTEXTO NÃO contiver a informação necessária, NÃO diga apenas "não sei".
   Em vez disso, responda de forma cordial e útil, por exemplo:
   "Não localizei essa informação específica na base de conhecimento atual.
   Recomendo consultar os documentos disponibilizados no portal da companhia.
   Caso não encontre, posso registrar um chamado para que um especialista valide
   o caso — deseja que eu faça isso? Se sim, para qual ferramenta: SAP ou MES?"

EXEMPLOS DE PERGUNTAS QUE VOCÊ SABE RESPONDER (quando houver contexto):
- [MM] Como resolver "estratégia de liberação não encontrada" no ME29N?
- [MM] Por que a fatura foi bloqueada no MIRO e como liberar (MRBR)?
- [MM] Como funciona a subcontratação (item categoria L)?
- [MM] Como consultar estoque em consignação de fornecedor?
- [MM] Divergência de quantidade no MIGO — como investigar?
- [MM] Como criar/alterar materiais em massa (MM17)?
- [PP] Ordem de produção não confirma no CO11N — o que verificar?
- [PP] MRP não gera necessidades no MD01N — o que fazer?
- [PP] Como funciona o backflush (baixa automática de componentes)?
- [QM] Lote de inspeção não é gerado na entrada de mercadoria — por quê?
- [QM] Como registrar a decisão de uso de um lote (QA32)?
- [WM] LT01 não determina o depósito de destino — o que revisar?
- [WM] Como tratar diferenças apontadas em uma OT (LI20)?
- [MES] Ordem não replica para o Opcenter — IDoc em status 51.
- [MES] Confirmação lançada no PAS-X não retorna ao SAP.

EXEMPLOS DE PERGUNTAS FORA DO SEU ESCOPO (use o contorno cordial e ofereça chamado):
- Política de férias, folha de pagamento ou benefícios (RH).
- Reset de senha de rede, VPN ou e-mail corporativo (Infraestrutura de TI).
- Assuntos não relacionados a SAP MM/PP/QM/WM ou às integrações MES.

CONTEXTO:
{contexto}

PERGUNTA: {pergunta}

RESPOSTA:"""

    def responder(self, pergunta: str) -> dict:
        """
        Retorna:
          {
            "tem_resposta": bool,
            "resposta": str,
            "fontes": [ {fonte, tipo, score} ],
            "precisa_chamado": bool
          }
        """
        recuperados = self.recuperar(pergunta)
        melhor_score = recuperados[0][2] if recuperados else 0.0

        # Base sem embasamento suficiente -> não inventa, contorna cordialmente.
        if melhor_score < LIMIAR_SIMILARIDADE:
            return {
                "tem_resposta": False,
                "resposta": MSG_SEM_RESPOSTA,
                "fontes": [],
                "precisa_chamado": True,
            }

        contexto = "\n\n".join(
            f"[Fonte: {m.get('fonte')} | tipo: {m.get('tipo')}]\n{t}"
            for t, m, s in recuperados
        )
        fontes = [{"fonte": m.get("fonte"), "tipo": m.get("tipo"), "score": round(s, 3)}
                  for _, m, s in recuperados]

        llm = self._get_llm()
        if llm is None:
            resposta = ("[Modo recuperação — sem LLM configurada]\n\n"
                        "Trechos mais relevantes encontrados na base:\n\n" + contexto[:1500])
            return {"tem_resposta": True, "resposta": resposta,
                    "fontes": fontes, "precisa_chamado": False}

        prompt = self._montar_prompt(contexto, pergunta)
        resposta = llm.invoke(prompt).content
        return {"tem_resposta": True, "resposta": resposta,
                "fontes": fontes, "precisa_chamado": False}


if __name__ == "__main__":
    base = os.path.join(os.path.dirname(__file__), "..", "data", "documentos")
    engine = RAGEngine(base)
    n = engine.indexar()
    print(f"Indexados {n} chunks.\n")
    for pergunta in [
        "Como resolver o erro de estrategia de liberacao no pedido de compra?",
        "Qual a politica de ferias do RH?",  # fora do escopo -> contorno cordial
    ]:
        print("PERGUNTA:", pergunta)
        r = engine.responder(pergunta)
        print("Tem resposta:", r["tem_resposta"], "| Precisa chamado:", r["precisa_chamado"])
        print("Resposta:", r["resposta"][:300])
        print("-" * 70)
