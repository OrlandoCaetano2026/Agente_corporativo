# -*- coding: utf-8 -*-
"""
api.py
------
API REST (FastAPI) que expõe o serviço de chamados do agente Orla_Tech.
Camada adequada para rodar no OCI (Compute, Container Instances ou OKE).

Endpoints:
  GET  /health            -> health check (para o OCI)
  GET  /tickets           -> lista os chamados da base
  POST /tickets/analisar  -> pré-analisa (ferramenta/módulo) sem criar
  POST /tickets           -> cria um chamado (requer confirmado=true)
  GET  /tickets/next-id   -> próximo ID sequencial

Executar localmente:
  uvicorn src.api:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import pandas as pd

from ticket_service import (Ticket, create_ticket, analisar,
                            _proximo_id, DEFAULT_XLSX, SHEET)

app = FastAPI(
    title="Orla_Tech - API de Chamados SAP",
    description="Serviço de criação de chamados do agente corporativo (ServiceToday).",
    version="2.0.0",
)


class DescricaoIn(BaseModel):
    descricao: str


class TicketIn(BaseModel):
    descricao: str
    modulo: str | None = None
    ferramenta: str | None = None
    sistema: str = "S/4HANA"
    prioridade: str = "P3"
    confirmado: bool = False


@app.get("/health")
def health():
    return {"status": "ok", "servico": "orla-tech-chamados"}


@app.get("/tickets/next-id")
def next_id():
    return {"proximo_id": _proximo_id(DEFAULT_XLSX)}


@app.post("/tickets/analisar")
def analisar_endpoint(payload: DescricaoIn):
    return analisar(payload.descricao)


@app.get("/tickets")
def listar():
    try:
        df = pd.read_excel(DEFAULT_XLSX, sheet_name=SHEET, dtype=str).fillna("")
        return {"total": len(df), "chamados": df.to_dict(orient="records")}
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Base de chamados não encontrada.")


@app.post("/tickets")
def criar(payload: TicketIn):
    t = Ticket(
        descricao=payload.descricao, modulo=payload.modulo,
        ferramenta=payload.ferramenta, sistema=payload.sistema,
        prioridade=payload.prioridade,
    )
    return create_ticket(t, confirmado=payload.confirmado)
