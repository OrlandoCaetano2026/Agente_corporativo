# -*- coding: utf-8 -*-
"""
main.py — PASSO 7: Interface conversacional (Streamlit)
-------------------------------------------------------
Interface web do Agente Corporativo de Suporte SAP da Orla_Tech.

Fluxo de abertura de chamado (guiado):
  1. O agente consulta a base (RAG) e responde se houver embasamento.
  2. Se NÃO houver, contorna cordialmente e pergunta se deseja abrir chamado
     e para qual FERRAMENTA (SAP ou MES).
  3. Detecta automaticamente o MÓDULO (MM/PP/QM/WM/MES) pelo texto do problema.
  4. Pergunta a PRIORIDADE (P1-Crítico, P2-Urgente, P3-Médio, P4-Leve).
  5. Cria o chamado com número sequencial único e registra na base.

Executar:
  streamlit run app/main.py
"""
import os
import sys

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(BASE_DIR, "src"))

import streamlit as st
from rag_engine import RAGEngine
from ticket_service import Ticket, create_ticket, analisar, PRIORIDADE_LABEL

DOCS = os.path.join(BASE_DIR, "data", "documentos")

st.set_page_config(page_title="Agente SAP · Orla_Tech", page_icon="🤖", layout="centered")


@st.cache_resource(show_spinner="Indexando a base de conhecimento...")
def carregar_engine():
    eng = RAGEngine(DOCS)
    eng.indexar()
    return eng


st.title("🤖 Agente de Suporte SAP — Orla_Tech")
st.caption("Especialista SAP · MM (foco), PP, QM, WM · ECC e S/4HANA · MES Opcenter e PAS-X")

engine = carregar_engine()

# ---------- Estado ----------
if "mensagens" not in st.session_state:
    st.session_state.mensagens = [
        {"role": "assistant",
         "content": "Olá! Sou o especialista de suporte SAP da Orla_Tech. Como posso ajudar você hoje?"}
    ]
# etapa do fluxo de chamado: None | 'ferramenta' | 'prioridade' | pronto
if "chamado" not in st.session_state:
    st.session_state.chamado = None

for m in st.session_state.mensagens:
    with st.chat_message(m["role"]):
        st.markdown(m["content"])


def add(role, content):
    st.session_state.mensagens.append({"role": role, "content": content})
    with st.chat_message(role):
        st.markdown(content)


def _sim(t): return t.strip().lower() in {"sim", "s", "yes", "y", "pode", "quero", "confirmo"}
def _nao(t): return t.strip().lower() in {"nao", "não", "n", "no"}

PRIOR_MAP = {"1": "P1", "2": "P2", "3": "P3", "4": "P4",
             "p1": "P1", "p2": "P2", "p3": "P3", "p4": "P4",
             "critico": "P1", "crítico": "P1", "urgente": "P2",
             "medio": "P3", "médio": "P3", "leve": "P4"}


if pergunta := st.chat_input("Digite sua dúvida sobre SAP..."):
    add("user", pergunta)
    c = st.session_state.chamado

    with st.chat_message("assistant"):
        # ===== FLUXO DE CHAMADO EM ANDAMENTO =====
        if c is not None:
            etapa = c["etapa"]

            # 1) Confirmar abertura + escolher ferramenta
            if etapa == "ferramenta":
                if _nao(pergunta):
                    resposta = "Sem problemas! Não abri nenhum chamado. Posso ajudar em algo mais? 😊"
                    st.session_state.chamado = None
                else:
                    texto = pergunta.strip().upper()
                    ferramenta = "MES" if "MES" in texto else ("SAP" if "SAP" in texto or _sim(pergunta) else None)
                    info = analisar(c["descricao"])
                    if ferramenta is None:
                        ferramenta = info["ferramenta"]
                    c["ferramenta"] = ferramenta
                    c["modulo"] = info["modulo"]
                    c["categoria"] = info["categoria"]
                    c["etapa"] = "prioridade"
                    resposta = (
                        f"Perfeito! Analisei o problema e identifiquei:\n"
                        f"- **Ferramenta:** {ferramenta}\n"
                        f"- **Módulo detectado:** {info['modulo']} ({info['categoria']})\n\n"
                        f"Qual a **prioridade**?\n"
                        f"- **P1** - Crítico · **P2** - Urgente · **P3** - Médio · **P4** - Leve"
                    )

            # 2) Escolher prioridade e criar
            elif etapa == "prioridade":
                prio = PRIOR_MAP.get(pergunta.strip().lower(), "P3")
                ticket = Ticket(
                    descricao=c["descricao"], modulo=c["modulo"],
                    ferramenta=c["ferramenta"], categoria=c["categoria"],
                    prioridade=prio,
                )
                r = create_ticket(ticket, confirmado=True)
                resposta = "✅ " + r["mensagem"]
                st.session_state.chamado = None

            else:
                resposta = "Desculpe, pode repetir?"
                st.session_state.chamado = None

            st.markdown(resposta)
            add_stateless = {"role": "assistant", "content": resposta}
            st.session_state.mensagens.append(add_stateless)

        # ===== PERGUNTA NORMAL (RAG) =====
        else:
            with st.spinner("Consultando a base de conhecimento..."):
                r = engine.responder(pergunta)
            resposta = r["resposta"]
            st.markdown(resposta)
            st.session_state.mensagens.append({"role": "assistant", "content": resposta})

            if r["fontes"]:
                with st.expander("📚 Fontes consultadas"):
                    for f in r["fontes"]:
                        st.write(f"- **{f['fonte']}** ({f['tipo']}) · relevância {f['score']}")

            if r["precisa_chamado"]:
                # inicia o fluxo de chamado
                st.session_state.chamado = {"descricao": pergunta, "etapa": "ferramenta"}


with st.sidebar:
    st.header("ℹ️ Sobre")
    st.write("Agente RAG corporativo da **Orla_Tech Consultoria** (especialista SAP).")
    st.write("Quando não encontra a resposta, orienta consultar o portal e oferece "
             "registrar um chamado no **ServiceToday**, escolhendo a ferramenta "
             "(**SAP/MES**), com módulo detectado automaticamente e prioridade **P1-P4**.")
    st.divider()
    st.caption("Prioridades: P1-Crítico (4h) · P2-Urgente (8h) · P3-Médio (16h) · P4-Leve (24h)")
    if st.button("🔄 Reiniciar conversa"):
        st.session_state.mensagens = st.session_state.mensagens[:1]
        st.session_state.chamado = None
        st.rerun()
